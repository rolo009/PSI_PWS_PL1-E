<?php


class seletorNumeros
{
    public $numerosSelecionados;
    public $userNumber;
    public function validateNumber($userNumber, $numerosBloqueio){

    }

    public function selection($userNumber){

    }

    public function checkSelectionTotal($totalDados){

    }

    public function clearSelection(){

    }

    public function selectionHasNumber($number){

    }
}